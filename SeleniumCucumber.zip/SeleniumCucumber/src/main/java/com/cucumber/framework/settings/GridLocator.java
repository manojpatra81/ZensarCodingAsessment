package com.cucumber.framework.settings;

public class GridLocator {
	
	public static final String cartId = "cart";

}
