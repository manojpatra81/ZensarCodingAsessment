
package com.cucumber.framework.configuration.browser;


public enum BrowserType {
	Firefox,
	Chrome,
	Iexplorer,
	PhantomJs,
	HtmlUnitDriver

}
