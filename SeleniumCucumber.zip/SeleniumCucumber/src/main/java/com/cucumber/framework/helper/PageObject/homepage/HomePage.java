package com.cucumber.framework.helper.PageObject.homepage;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;


import com.cucumber.framework.helper.Logger.LoggerHelper;
import com.cucumber.framework.helper.PageObject.PageBase;

import com.cucumber.framework.settings.ObjectRepo;

public class HomePage extends PageBase {
	
	private WebDriver driver;
	private final Logger log = LoggerHelper.getLogger(HomePage.class);

	public HomePage(WebDriver driver) {
		super(driver);
		this.driver = driver;
	}
	
	@FindBy(how=How.XPATH,using="//input[@name=\"q\"]")
	public WebElement searchtextbox;
	
	@FindBy(how=How.XPATH,using="//h3[contains (text(),\"What is Automated Testing\")]")
	public WebElement returnterm;
	
	
	//
	public void search(String searchStr) {
		searchtextbox.sendKeys(searchStr,Keys.ENTER);
		
		log.info(searchStr);
	}
	
	public boolean getReturnItem(String expectedreturnitem) {
		String Actualreturnitem=returnterm.getText();
		if(Actualreturnitem.contains(expectedreturnitem))
			return true;
		else {
			return false;
		}
		
		
	}
	public WebDriver getDriver() {
		return this.driver;
	}
	
	
}
