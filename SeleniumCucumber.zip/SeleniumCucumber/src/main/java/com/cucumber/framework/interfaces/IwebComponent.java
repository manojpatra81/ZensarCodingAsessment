
package com.cucumber.framework.interfaces;


public interface IwebComponent {

}
