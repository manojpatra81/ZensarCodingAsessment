package com.cucumber.framework.stepdefinition;

import org.testng.Assert;

import com.cucumber.framework.helper.PageObject.homepage.HomePage;
import com.cucumber.framework.settings.ObjectRepo;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class SearchStepDfn {
	
	private HomePage hPage;

	@Given("^: I am at the google home page$")
	public void _i_am_at_the_google_home_page() throws Throwable {
		ObjectRepo.driver.get(ObjectRepo.reader.getWebsite());
		hPage = new HomePage(ObjectRepo.driver);
		ObjectRepo.data.put("HomePage", hPage);
	}

	
	@When("^: I search for \"([^\"]*)\"$")
	public void i_search_for_automation_testing(String search) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		hPage.search(search); 
	}

	@Then("^: Validate the first returned item having term \"([^\"]*)\"$")
	public void validate_the_first_returned_item_having_term_Automated_Testing(String Expectedterm) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Assert.assertTrue(hPage.getReturnItem(Expectedterm));
	}

}
